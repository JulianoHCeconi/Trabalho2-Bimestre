package com.example.testetrabalho.Dao;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import com.example.testetrabalho.helper.DataBaseHelper;
import com.example.testetrabalho.model.Usuario;
import com.example.testetrabalho.view.EsqueciSenha;
import com.example.testetrabalho.view.LoginActivity;

import java.util.ArrayList;

public class UsuarioDao implements IGenericDao<Usuario> {

    private SQLiteOpenHelper openHelper;
    private SQLiteDatabase baseDados;

    private String[] colunas = {"ID", "NOME", "EMAIL", "SENHA"};
    private String tabela = "USUARIOS";
    private Context context;

    private static UsuarioDao instancia;

    public static UsuarioDao getInstancia(Context context) {
        if (instancia == null) {
            instancia = new UsuarioDao(context);
        }
        return instancia;
    }

    public UsuarioDao(Context context) {
        this.context = context;
        openHelper = new DataBaseHelper(this.context);
        baseDados = openHelper.getWritableDatabase();
    }

    public long insert(Usuario usuario) {
        try {
            ContentValues valores = new ContentValues();
            valores.put(colunas[1], usuario.getNome());
            valores.put(colunas[2], usuario.getEmail());
            valores.put(colunas[3], usuario.getSenha());

            return baseDados.insert(tabela, null, valores);
        } catch (SQLException ex) {
            Log.e("UsuarioDao", "ERRO: Usuario.insert(): " + ex.getMessage());
        }
        return 0;
    }

    @Override
    public long update(Usuario usuario) {
        try {
            ContentValues valores = new ContentValues();
            valores.put(colunas[1], usuario.getNome());
            valores.put(colunas[2], usuario.getEmail());
            valores.put(colunas[3], usuario.getSenha());

            String[] identificador = {String.valueOf(usuario.getId())};
            return baseDados.update(tabela, valores, "ID = ?", identificador);
        } catch (SQLException ex) {
            Log.e("UsuarioDao", "ERRO: Usuario.update(): " + ex.getMessage());
        }
        return 0;
    }

    @Override
    public long delete(Usuario usuario) {
        return baseDados.delete(tabela, "EMAIL = ?", new String[]{usuario.getEmail()});
    }

    public Usuario getById(int id) {
        Cursor cursor = baseDados.query(tabela, colunas,
                "ID = ?", new String[]{String.valueOf(id)}, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            Usuario usuario = new Usuario();
            usuario.setId(cursor.getInt(0));
            usuario.setNome(cursor.getString(1));
            usuario.setEmail(cursor.getString(2));
            usuario.setSenha(cursor.getString(3));
            cursor.close();
            return usuario;
        }
        return null;
    }

    public Usuario getByEmail(String email) {
        Cursor cursor = baseDados.query(tabela, colunas,
                "EMAIL = ?", new String[]{email}, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            Usuario usuario = new Usuario();
            usuario.setId(cursor.getInt(0));
            usuario.setNome(cursor.getString(1));
            usuario.setEmail(cursor.getString(2));
            usuario.setSenha(cursor.getString(3));
            cursor.close();
            return usuario;
        }
        return null;
    }

    @Override
    public ArrayList<Usuario> getAll() {
        ArrayList<Usuario> usuarios = new ArrayList<>();
        Cursor cursor = baseDados.query(tabela, colunas,
                null, null, null, null, null);
        if (cursor != null) {
            while (cursor.moveToNext()) {
                Usuario usuario = new Usuario();
                usuario.setId(cursor.getInt(0));
                usuario.setNome(cursor.getString(1));
                usuario.setEmail(cursor.getString(2));
                usuario.setSenha(cursor.getString(3));
                usuarios.add(usuario);
            }
            cursor.close();
        }
        return usuarios;
    }

    public boolean emailExistente(String email) {
        Cursor cursor = baseDados.rawQuery
                ("SELECT * FROM " + tabela + " WHERE EMAIL = ?", new String[]{email});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public boolean autenticarUsuario(String email, String senha) {
        Cursor cursor = baseDados.rawQuery("SELECT * FROM " + tabela + " WHERE " +
                "EMAIL = ? AND SENHA = ?", new String[]{email, senha});
        boolean authenticated = cursor.getCount() > 0;
        cursor.close();
        return authenticated;
    }

    public void alterarSenha(String email, String senha){
        SQLiteDatabase db = openHelper.getWritableDatabase();

        String[] args = {email};
        Cursor cursor = db.rawQuery("SELECT * FROM USUARIOS WHERE EMAIL = ?", args);

        try {
            if(cursor.moveToFirst()){
                ContentValues values = new ContentValues();
                values.put("SENHA", senha);
                int rows = db.update("USUARIOS", values, "EMAIL = ?", args);

                if(rows > 0 ){
                    Toast.makeText(context, "Sua senha foi alterada!",
                            Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(context, "Ocorreu um erro ao alterar sua senha!",
                            Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(context, "Email não encontrado!",
                        Toast.LENGTH_SHORT).show();
            }
        } finally {
            cursor.close();
            db.close();
        }
    }
}