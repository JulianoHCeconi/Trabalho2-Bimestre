package com.example.testetrabalho.view;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.testetrabalho.R;
import com.example.testetrabalho.helper.DataBaseHelper;

public class CadastroActivity extends AppCompatActivity {

    private EditText edNome, edEmail, edSenha, edConfirmarSenha;
    private Button btCadastrar, btVoltar;
    private DataBaseHelper dbHelper;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cadastro);

        dbHelper = new DataBaseHelper(this);

        edNome = findViewById(R.id.edNome);
        edEmail = findViewById(R.id.edEmail);
        edSenha = findViewById(R.id.edSenha);
        edConfirmarSenha = findViewById(R.id.edConfirmarSenha);
        btCadastrar = findViewById(R.id.btCadastrar);
        btVoltar = findViewById(R.id.btVoltar);

        btCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nome = edNome.getText().toString();
                String email = edEmail.getText().toString();
                String senha = edSenha.getText().toString();
                String confirmarSenha = edConfirmarSenha.getText().toString();

                if (nome.isEmpty() || email.isEmpty() || senha.isEmpty() ||
                                                                confirmarSenha.isEmpty()) {
                    Toast.makeText(CadastroActivity.this, "Preencha todos os campos",
                                                                    Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!emailValido(email)) {
                    Toast.makeText(CadastroActivity.this, "Formato de e-mail inválido",
                                                                    Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!senha.equals(confirmarSenha)) {
                    Toast.makeText(CadastroActivity.this, "As senhas não coincidem",
                                                                    Toast.LENGTH_SHORT).show();
                    return;
                }

                if(emailExistente(email)){
                    Toast.makeText(CadastroActivity.this,
                            "Já existe outra conta com esse endereço de e-mail",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                cadastrarUsuario(nome, email, senha);
            }
        });

        btVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }

    public boolean emailValido(String email){
        return email != null && Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    public boolean emailExistente(String email){
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String query = "SELECT * FROM USUARIOS WHERE EMAIL = ?";
        Cursor cursor = db.rawQuery(query, new String[]{email});

        boolean existente = cursor.getCount() > 0;
        cursor.close();
        db.close();

        return existente;
    }

    private void cadastrarUsuario(String nome, String email, String senha){
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("NOME", nome);
        values.put("EMAIL", email);
        values.put("SENHA", senha);

        long result = db.insert("USUARIOS", null, values);

        if(result != -1){
            Toast.makeText(this, "Seu cadastro foi feito com sucesso!",
                                                            Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(CadastroActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();

        }else{
            Toast.makeText(this,"Erro ao realizar seu cadastro!",
                                                            Toast.LENGTH_SHORT).show();
        }
        db.close();
    }

}