package com.example.testetrabalho.view;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.testetrabalho.R;
import com.example.testetrabalho.Dao.UsuarioDao;

public class EsqueciSenha extends AppCompatActivity {

    private EditText edEmailRedefinir, edNovaSenha, edRepetirSenhaRedefinir;
    private Button btRedefinirSenha, btCancelaEsqueciSenha;
    private UsuarioDao usuarioDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_esqueci_senha);

        usuarioDao = UsuarioDao.getInstancia(this);

        edEmailRedefinir = findViewById(R.id.edEmailRedefinir);
        edNovaSenha = findViewById(R.id.edNovaSenha);
        edRepetirSenhaRedefinir = findViewById(R.id.edRepetirSenhaRedefinir);
        btRedefinirSenha = findViewById(R.id.btRedefinirSenha);
        btCancelaEsqueciSenha = findViewById(R.id.btCancelaEsqueciSenha);

        btRedefinirSenha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = edEmailRedefinir.getText().toString();
                String senha = edNovaSenha.getText().toString();
                String confirmaSenha = edRepetirSenhaRedefinir.getText().toString();

                if (email.isEmpty() || senha.isEmpty() || confirmaSenha.isEmpty()) {
                    Toast.makeText(EsqueciSenha.this,
                            "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                } else if (!senha.equals(confirmaSenha)) {
                    Toast.makeText(EsqueciSenha.this,
                            "As senhas não coincidem", Toast.LENGTH_SHORT).show();
                } else {
                    alterarSenha(email, senha);
                }
            }
        });

        btCancelaEsqueciSenha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    private void alterarSenha(String email, String novaSenha) {
        if (usuarioDao.emailExistente(email)) {
            usuarioDao.alterarSenha(email, novaSenha);
        } else {
            Toast.makeText(this, "Email não encontrado!", Toast.LENGTH_SHORT).show();
        }
    }
}