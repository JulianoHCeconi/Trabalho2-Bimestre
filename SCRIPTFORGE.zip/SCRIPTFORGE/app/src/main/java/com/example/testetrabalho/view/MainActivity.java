package com.example.testetrabalho.view;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.testetrabalho.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {

    private FloatingActionButton btJava01, btPython01, btCsharp01,
            btCmais01, btSair;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        btJava01 = findViewById(R.id.btJava01);
        btPython01 = findViewById(R.id.btPython01);
        btCsharp01 = findViewById(R.id.btCsharp01);
        btCmais01 = findViewById(R.id.btCmais01);
        btSair = findViewById(R.id.btSair);

        btJava01.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, TelaProjetoActivity.class);
                startActivity(intent);
            }
        });

        btSair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });

        btPython01.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, TelaProjetoPythonActivity.class);
                startActivity(intent);
            }
        });

        btCsharp01.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, TelaProjetoCSharpActivity.class);
                startActivity(intent);
            }
        });

        btCmais01.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, TelaProjetoCMaisActivity.class);
                startActivity(intent);
            }
        });

    }
}