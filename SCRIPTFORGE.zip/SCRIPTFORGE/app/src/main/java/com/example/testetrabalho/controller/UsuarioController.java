package com.example.testetrabalho.controller;

import android.content.Context;
import android.content.Intent;
import android.util.Patterns;
import android.widget.Toast;
import com.example.testetrabalho.Dao.UsuarioDao;
import com.example.testetrabalho.model.Usuario;
import com.example.testetrabalho.view.LoginActivity;

public class UsuarioController {

    private final Context context;

    public UsuarioController(Context context) {
        this.context = context;
    }

    public void cadastrarUsuario(String nome, String email, String senha, String confirmarSenha) {
        if (nome.isEmpty() || email.isEmpty() || senha.isEmpty() || confirmarSenha.isEmpty()) {
            Toast.makeText(context, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(context, "Formato de e-mail inválido", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!senha.equals(confirmarSenha)) {
            Toast.makeText(context, "As senhas não coincidem", Toast.LENGTH_SHORT).show();
            return;
        }

        UsuarioDao usuarioDao = UsuarioDao.getInstancia(context);
        if (usuarioDao.emailExistente(email)) {
            Toast.makeText(context, "Já existe outra conta com esse e-mail", Toast.LENGTH_SHORT).show();
            return;
        }

        Usuario usuario = new Usuario();
        usuario.setNome(nome);
        usuario.setEmail(email);
        usuario.setSenha(senha);

        long result = usuarioDao.insert(usuario);

        if (result != -1) {
            Toast.makeText(context,
                    "Cadastro realizado com sucesso!", Toast.LENGTH_SHORT).show();
            context.startActivity(new Intent(context, LoginActivity.class));
        } else {
            Toast.makeText(context,
                    "Erro ao realizar cadastro", Toast.LENGTH_SHORT).show();
        }
    }

    public void redefinirSenha(String email, String novaSenha, String confirmarSenha) {
        if (email.isEmpty() || novaSenha.isEmpty() || confirmarSenha.isEmpty()) {
            Toast.makeText(context, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!novaSenha.equals(confirmarSenha)) {
            Toast.makeText(context, "As senhas não coincidem", Toast.LENGTH_SHORT).show();
            return;
        }

        UsuarioDao usuarioDao = UsuarioDao.getInstancia(context);
        Usuario usuario = usuarioDao.getByEmail(email);
        if (usuario == null) {
            Toast.makeText(context, "E-mail não encontrado", Toast.LENGTH_SHORT).show();
            return;
        }

        usuario.setSenha(novaSenha);
        long result = usuarioDao.update(usuario);

        if (result > 0) {
            Toast.makeText(context, "Senha alterada com sucesso!", Toast.LENGTH_SHORT).show();
            context.startActivity(new Intent(context, LoginActivity.class));
        } else {
            Toast.makeText(context, "Erro ao alterar a senha", Toast.LENGTH_SHORT).show();
        }
    }

    public boolean validarLogin(String email, String senha) {
        return UsuarioDao.getInstancia(context).autenticarUsuario(email, senha);
    }
}
