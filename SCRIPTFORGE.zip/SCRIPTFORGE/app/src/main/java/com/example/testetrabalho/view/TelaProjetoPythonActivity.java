package com.example.testetrabalho.view;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.testetrabalho.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class TelaProjetoPythonActivity extends AppCompatActivity {

    private Button btPastaPython;
    private FloatingActionButton btVoltarPython;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_tela_projeto_python);

        btPastaPython = findViewById(R.id.btPastaPython);
        btVoltarPython = findViewById(R.id.btVoltarPython);

        btVoltarPython.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(TelaProjetoPythonActivity.this,
                        MainActivity.class);
                startActivity(intent);
            }
        });

        btPastaPython.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(TelaProjetoPythonActivity.this,
                        TelaCodigoPythonActivity.class);
                startActivity(intent);
            }
        });

    }
}