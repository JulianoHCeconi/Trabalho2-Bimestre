package com.example.testetrabalho.view;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.testetrabalho.R;
import com.example.testetrabalho.helper.DataBaseHelper;

public class LoginActivity extends AppCompatActivity {

    private EditText edEmail, edSenha;
    private Button btEntrar, btCadastrar, btEsqueciSenha;
    private DataBaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        dbHelper = new DataBaseHelper(this);

        edEmail = findViewById(R.id.edEmail);
        edSenha = findViewById(R.id.edSenha);
        btEntrar = findViewById(R.id.btEntrar);
        btCadastrar = findViewById(R.id.btCadastrar);
        btEsqueciSenha = findViewById(R.id.btEsqueciSenha);

        btEsqueciSenha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this, EsqueciSenha.class);
                startActivity(intent);
            }
        });

        btEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = edEmail.getText().toString().trim();
                String senha = edSenha.getText().toString();

                if(!emailValido(email)){
                    Toast.makeText(LoginActivity.this,
                            "Digite um e-mail válido", Toast.LENGTH_SHORT).show();
                }
                if(email.isEmpty()){
                    Toast.makeText(LoginActivity.this, "O campo e-mail é obrigatório!",
                            Toast.LENGTH_SHORT).show();
                }if(senha.isEmpty()){
                    Toast.makeText(LoginActivity.this, "O campo senha é obrigatório!",
                            Toast.LENGTH_SHORT).show();
                }else{
                    verificaLogin(email, senha);
                }
            }
        });

        btCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this, CadastroActivity.class);
                startActivity(intent);
            }
        });
    }

    public boolean emailValido(String email){
        return email != null && Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    private void verificaLogin(String email, String senha){
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[]colunas = {"EMAIL", "SENHA"};
        String selecao = "EMAIL = ? AND SENHA = ?";
        String[]selectionArgs = {email, senha};

        Cursor cursor = db.query("USUARIOS", colunas, selecao, selectionArgs,
                null, null, null);

        if(cursor.moveToFirst()){
            Toast.makeText(this, "Login realizado!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        }else{
            Toast.makeText(this, "Usuáio ou senha incorretos!" +
                    " Verifique e tente novamente", Toast.LENGTH_SHORT).show();
        }
        cursor.close();
        db.close();
    }

}