package com.example.testetrabalho.Dao;

import java.util.ArrayList;

public interface IGenericDao<Usuario> {

    long insert(Usuario usuario);

    long update(Usuario usuario);

    long delete(Usuario usuario);

    Usuario getById(int id);

    ArrayList<Usuario> getAll();
}
